#!/usr/bin/python3

def test(* , a):
	print(a)

print(test(1,a=1))